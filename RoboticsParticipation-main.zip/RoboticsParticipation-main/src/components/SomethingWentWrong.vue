<template>
    <h2>Oops!</h2>
    <h3>Something went wrong. Please try submitting again.</h3>
</template>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h2 {
  font-size: 2em;
  font-style: italic;
}
h3 {
  font-size: 1.5em;
  font-style: italic;
}
</style>